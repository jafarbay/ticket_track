const API_URL = "https://turkmenback.turkmenistanairlines.ru/api/find";
const BOOKING_URL = "https://turkmenistanairlines.ru/air/";
const headers = {
  "Content-Type": "application/json",
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
};

const payloadTemplate = {
  adult: "1",
  child: "0",
  class_type: "Y",
  flight_type: "ONE_WAY",
  infant: "0",
  segment: [
    {
      from: "ASB",
      to: "", // Заполняется динамически: KZN или DME
      date: ""
    }
  ]
};

// Функция для форматирования даты в DD.MM.YYYY
function formatDateForBooking(dateStr) {
  const date = new Date(dateStr);
  const day = String(date.getDate()).padStart(2, "0");
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const year = date.getFullYear();
  return `${day}.${month}.${year}`;
}

// Функция для создания ссылки на бронирование
function createBookingLink(direction, flightDate) {
  const city = direction === "KZN" ? "KZN" : "DME";
  const formattedDate = formatDateForBooking(flightDate);
  return `${BOOKING_URL}fromCity=ASB&from=ASB&toCity=${city}&to=${city}&dateFrom=${formattedDate}&dateTo=null&class=Y&adult=1&child=0&infant=0`;
}

// Функция для получения дат по дням недели в зависимости от направления
function getFlightDates(startDate, endDate, direction) {
  const dates = [];
  let currentDate = new Date(startDate);
  const flightDays = direction === "KZN" ? [0, 3] : [1, 5]; // KZN: Воскресенье (0), Среда (3); DME: Понедельник (1), Пятница (5)

  while (currentDate <= endDate) {
    if (flightDays.includes(currentDate.getDay())) {
      dates.push(currentDate.toISOString().split("T")[0]);
    }
    currentDate.setDate(currentDate.getDate() + 1);
  }
  return dates;
}

// Функция проверки билетов
async function checkTickets(flightDate, direction) {
  const payload = { ...payloadTemplate };
  payload.segment[0].to = direction;
  payload.segment[0].date = flightDate;

  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: headers,
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      throw new Error(`HTTP error: ${response.status}`);
    }

    const data = await response.json();

    if (Array.isArray(data) && data.length > 0) {
      const flightInfo = data[0];
      const seats = flightInfo.seats || 0;
      const totalAmount = flightInfo.totalAmount || "N/A";
      const departureTime = flightInfo.directions?.[0]?.segments?.[0]?.DepartureDateTime || "N/A";

      if (seats > 0) {
        const bookingLink = createBookingLink(direction, flightDate);
        return `<div class="result success">
          <strong>Found tickets for ASB → ${direction} on ${flightDate}!</strong><br>
          Seats: ${seats}<br>
          Price: ${totalAmount} RUB<br>
          Departure: ${departureTime}<br>
          <a href="${bookingLink}" target="_blank" class="book-button">Book Now</a>
        </div>`;
      } else {
        return `<div class="result">No tickets for ASB → ${direction} on ${flightDate} (Seats: 0)</div>`;
      }
    } else {
      return `<div class="result">No flight data for ASB → ${direction} on ${flightDate}</div>`;
    }
  } catch (error) {
    return `<div class="result error">Error checking ASB → ${direction} on ${flightDate}: ${error.message}</div>`;
  }
}

// Обработчик кнопки
document.getElementById("startCheck").addEventListener("click", async () => {
  const direction = document.getElementById("direction").value;
  const endDateInput = document.getElementById("endDate").value;
  const resultsDiv = document.getElementById("results");

  if (!endDateInput) {
    resultsDiv.innerHTML = '<div class="result error">Please select an end date!</div>';
    return;
  }

  const endDate = new Date(endDateInput);
  const startDate = new Date();
  if (endDate < startDate) {
    resultsDiv.innerHTML = '<div class="result error">End date must be in the future!</div>';
    return;
  }

  resultsDiv.innerHTML = `<div class="result"><div class="loader"></div>Checking flights for ASB → ${direction}...</div>`;
  const datesToCheck = getFlightDates(startDate, endDate, direction);

  const results = [];
  for (const flightDate of datesToCheck) {
    const result = await checkTickets(flightDate, direction);
    results.push(result);
    resultsDiv.innerHTML = results.join("");
    await new Promise(resolve => setTimeout(resolve, 1000)); // Задержка 2 секунды между запросами
  }
});