// Опционально: если нужна фоновая проверка, можно добавить логику здесь
console.log("Background script loaded");